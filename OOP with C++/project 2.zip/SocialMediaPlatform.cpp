/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#include "SocialMediaPlatform.h"
#include "LinkedList.h"
#include "User.h"
#include "Content.h"
#include "ContentCreator.h"
#include <iostream>
#include <string>
using namespace std;

SocialMediaPlatform::SocialMediaPlatform() {
	creatorsPtr = &creators;
}

SocialMediaPlatform::~SocialMediaPlatform() {
	creators.clear();
	users.clear();
	contents.clear();
}

void SocialMediaPlatform::addRegularUser(const int regularUserId, const string name) {
	bool found = false;
	for (int i = 1;i <= users.getLength(); i++) {
		if (users.getNode(i)->getItem().getID() == regularUserId) {
			found = true;
			cout << "Cannot add regular user. There is already a regular user with ID " << regularUserId << "." << endl;
		}
	}
	if (!found) {
		User newUser(regularUserId, name);
		bool added = false;
		for (int k = 1; k <= users.getLength(); k++) {
			if (users.getNode(k)->getItem().getID() >= regularUserId) {
				users.insert(k, newUser);
				cout << "Added regular user " << regularUserId << "." << endl;
				added = true;
				break;
			}
		}
		if (users.getLength() == 0) {
			users.insert(1, newUser);
			cout << "Added regular user " << regularUserId << "." << endl;
			added = true;
		}
		if (!added) {
			users.insert(users.getLength() + 1, newUser);
			cout << "Added regular user " << regularUserId << "." << endl;
		}
	}
}

void SocialMediaPlatform::removeRegularUser(const int regularUserId) {
	bool found = false;
	for (int i = 1; i <= users.getLength(); i++) {
		if (users.getNode(i)->getItem().getID() == regularUserId) {
			found = true;
			users.remove(i);
			cout << "Removed regular user " << regularUserId << "." << endl;
			for (int k = 1; k <= creators.getLength(); k++) {
				creators.getNode(k)->getItem().removeFollowerDeleted(regularUserId);
			}
		}
	}
	if (!found) {
		cout << "Cannot remove regular user. There is no regular user with ID " << regularUserId << "." << endl;
	}
}

void SocialMediaPlatform::addContentCreator(const int contentCreatorId, const string name) {
	bool found = false;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getEntry(i).getID() == contentCreatorId) {
			found = true;
			cout << "Cannot add content creator. There is already a content creator with ID " << contentCreatorId << "." << endl;
		}
	}
	if (!found) {
		bool added = false;
		ContentCreator newCreator(contentCreatorId, name);
		for (int k = 1; k <= creators.getLength(); k++) {
			if (creators.getEntry(k).getID() >= contentCreatorId) {
				creators.insert(k, newCreator); 
				cout << "Added content creator " << contentCreatorId << "." << endl;
				added = true;
				break;
			}
		}
		if (creators.getLength() == 0) {
			creatorsPtr->insert(1, newCreator);
			cout << "Added content creator " << contentCreatorId << "." << endl;
			added = true;
		}
		if (!added) {
			creators.insert(creators.getLength() + 1, newCreator);
			cout << "Added content creator " << contentCreatorId << "." << endl;
		}
	}
}

void SocialMediaPlatform::removeContentCreator(const int contentCreatorId) {
	bool found = false;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
			found = true;
			if (i == 1) {
				for (int k = 1; k <= creators.getNode(i)->getItem().getContentCount(); k++) {
					for (int l = 1; l <= contents.getLength(); l++) {
						if (contents.getEntry(l).getID() == creators.getEntry(i).getContents().getEntry(k).getID()) {
							contents.remove(l);
						}
					}
				}
				creatorsPtr->remove(1);
			}
			else {
				for (int k = 1; k <= creators.getNode(i)->getItem().getContentCount(); k++) {
					for (int l = 1; l <= contents.getLength(); l++) {
						if (contents.getEntry(l).getID() == creators.getEntry(i).getContents().getEntry(k).getID()) {
							contents.remove(l);
						}
					}
				}
				creators.remove(i);
			}
			cout << "Removed content creator " << contentCreatorId << "." << endl;
		}
	}
	if (!found) {
		cout << "Cannot remove content creator. There is no content creator with ID " << contentCreatorId << "." << endl;
	}
}

void SocialMediaPlatform::addContent(const int contentCreatorId, const int contentId, const string title) {
	bool found = false;
	for (int i = 1; i <= contents.getLength(); i++) {
		if (contents.getNode(i)->getItem().getID() == contentId) {
			found = true;
			cout << "Cannot add content. There is already a content with ID " << contentId << "." << endl;
		}
	}
	if (!found) {
		int creatorIndex = -1;
		for (int i = 1; i <= creators.getLength(); i++) {
			if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
				found = true;
				creatorIndex = i;
			}
		}
		if (!found) {
			cout << "Cannot add content. There is no content creator with ID " << contentCreatorId << "." << endl;
		}
		else {
			bool added = false;
			Content newContent(contentId, title);
			for (int k = 1; k <= contents.getLength(); k++) {
				if (contents.getNode(k)->getItem().getID() >= contentId) {
					contents.insert(k, newContent); 
					creators.getNode(creatorIndex)->getItem().addContent(contentId, title);
					cout << "Added content " << contentId << "." << endl;
					added = true;
					break;
				}
			}
			if (contents.getLength() == 0) {
				contents.insert(1, newContent);
				creators.getNode(creatorIndex)->getItem().addContent(contentId, title);
				cout << "Added content " << contentId << "." << endl;
				added = true;
			}
			else {
				if (!added) {
					contents.insert(contents.getLength() + 1, newContent);
					creators.getNode(creatorIndex)->getItem().addContent(contentId, title);
					cout << "Added content " << contentId << "." << endl;
				}
			}
		}
	}
}

void SocialMediaPlatform::removeContent(const int contentCreatorId, const int contentId) {
	bool found = false;
	int contentIndex = -1;
	for (int i = 1; i <= contents.getLength(); i++) {
		if (contents.getNode(i)->getItem().getID() == contentId) {
			contentIndex = i;
			
		}
	}
		int creatorIndex = -1;
		for (int i = 1; i <= creators.getLength(); i++) {
			if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
				creatorIndex = i;
				found = true;
				int first = creators.getNode(creatorIndex)->getItem().getContentCount();
				creators.getNode(creatorIndex)->getItem().removeContent(contentId);
				int second = creators.getNode(creatorIndex)->getItem().getContentCount();
				if (second == first - 1) {
					contents.remove(contentIndex);
				}
			}
		}
		if (!found) {
			cout << "Cannot remove content. There is no content creator with ID " << contentCreatorId << "." << endl;
		}
}

void SocialMediaPlatform::followContentCreator(const int regularUserId, const int contentCreatorId) {
	bool found1 = false;
	bool found2 = false;
	int creatorIndex = -1;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
			found1 = true;
			creatorIndex = i;
		}
	}
	for (int i = 1; i <= users.getLength(); i++) {
		if (users.getNode(i)->getItem().getID() == regularUserId) {
			found2 = true;
		}
	}
	if (!found1 || !found2) {
		cout << "Cannot follow. Regular user and/or content creator ID does not exist." << endl;
	}
	else {
		creators.getNode(creatorIndex)->getItem().addFollower(regularUserId);
	}
}

void SocialMediaPlatform::unfollowContentCreator(const int regularUserId, const int contentCreatorId) {
	bool found1 = false;
	bool found2 = false;
	int creatorIndex = -1;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
			found1 = true;
			creatorIndex = i;
		}
	}
	for (int i = 1; i <= users.getLength(); i++) {
		if (users.getNode(i)->getItem().getID() == regularUserId) {
			found2 = true;
		}
	}
	if (!found1 || !found2) {
		cout << "Cannot unfollow. Regular user and/or content creator ID does not exist." << endl;
	}
	else {
		creators.getNode(creatorIndex)->getItem().removeFollower(regularUserId);
	}
}

void SocialMediaPlatform::showFollowersOf(const int contentCreatorId)const {
	bool found1 = false;
	int creatorIndex = -1;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
			found1 = true;
			creatorIndex = i;
		}
	}
	if (!found1) {
		cout << "Cannot show. There is no content creator with ID " << contentCreatorId << "." << endl;
	}
	else {
		creators.getNode(creatorIndex)->getItem().showFollowers();
	}
}

void SocialMediaPlatform::showContentsOf(const int contentCreatorId)const {
	bool found1 = false;
	int creatorIndex = -1;
	for (int i = 1; i <= creators.getLength(); i++) {
		if (creators.getNode(i)->getItem().getID() == contentCreatorId) {
			found1 = true;
			creatorIndex = i;
		}
	}
	if (!found1) {
		cout << "Cannot show. There is no content creator with ID " << contentCreatorId << "." << endl;
	}
	else {
		creators.getNode(creatorIndex)->getItem().showContents();
	}
}

void SocialMediaPlatform::showAllRegularUsers()const {
	cout << "Regular users in the social media platform:" << endl;
	if (users.getLength() == 0) {
		cout << "None" << endl;
	}
	else {
		for (int i = 1; i <= users.getLength(); i++) {
			cout << users.getNode(i)->getItem().getID() << ", " << users.getNode(i)->getItem().getName() << endl;
		}
	}
}

void SocialMediaPlatform::showAllContentCreators()const {
	cout << "Content creators in the social media platform:" << endl;
	if (creators.getLength() == 0) {
		cout << "None" << endl;
	}
	else {
		for (int i = 1; i <= creators.getLength(); i++) {
			cout << creators.getNode(i)->getItem().getID() << ", " << creators.getNode(i)->getItem().getName() << ", " << creators.getNode(i)->getItem().getFollowerCount() << " follower(s), " << creators.getNode(i)->getItem().getContentCount() << " content(s)" << endl;
		}
	}
}


