/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#include "Content.h"

Content::Content(int ID, string title) {
	this->ID = ID;
	this->title = title;
}

int Content::getID() {
	return ID;
}
