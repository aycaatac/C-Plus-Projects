/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef NODE_
#define NODE_

#pragma once

template<class ItemType>

class Node
{
private:
	ItemType item;
	Node<ItemType>* next;
public:
	Node();
	Node(const ItemType& item);
	void setNext(Node<ItemType>* nextNode);
	const ItemType& getItem() const;
	ItemType& getItem();
	Node<ItemType>* getNext() const;
};

#endif 

template <class ItemType>
Node<ItemType>::Node() {
	this->next = nullptr;
}

template <class ItemType>
Node<ItemType>::Node(const ItemType& item) {
	this->item = item;
	this->next = nullptr;
}

template <class ItemType>
void Node<ItemType>::setNext(Node<ItemType>* nexth){
	this->next = nexth;
}

template <class ItemType>
const ItemType& Node<ItemType>::getItem() const {
	return item;
}

template <class ItemType>
ItemType& Node<ItemType>::getItem() {
	return item;
}

template <class ItemType>
Node<ItemType>* Node<ItemType>::getNext() const {
	return next;
}