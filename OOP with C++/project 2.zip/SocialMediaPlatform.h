/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef SMP_
#define SMP_

#pragma once
#include "LinkedList.h"
#include "User.h"
#include "Content.h"
#include "ContentCreator.h"
#include "Node.h"
#include <iostream>
#include <string>
using namespace std;

class SocialMediaPlatform{ 
private:
	LinkedList<User> users;
	LinkedList<Content> contents;
	LinkedList<ContentCreator> creators;
	LinkedList<ContentCreator>* creatorsPtr;
public: 
	SocialMediaPlatform(); 
	~SocialMediaPlatform(); 
	void addRegularUser(const int regularUserId,const string name); 
	void removeRegularUser(const int regularUserId); 
	void addContentCreator(const int contentCreatorId,const string name);
	void removeContentCreator(const int contentCreatorId); 
	void addContent(const int contentCreatorId,const int contentId,const string title); 
	void removeContent(const int contentCreatorId,const int contentId); 
	void followContentCreator(const int regularUserId,const int contentCreatorId); 
	void unfollowContentCreator(const int regularUserId,const int contentCreatorId); 
	void showFollowersOf(const int contentCreatorId)const; 
	void showContentsOf(const int contentCreatorId)const; 
	void showAllRegularUsers()const; 
	void showAllContentCreators()const;
};

#endif