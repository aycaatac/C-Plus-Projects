/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef USER_
#define USER_

#pragma once
#include <iostream>
#include <string>
#include "Node.h"
using namespace std;
class User
{
private:
	int ID;
	string name;
public:
	User(int ID = -5, string name = "");
	int getID();
	string getName();
};

#endif 

