/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef CONTENT_
#define CONTENT_

#pragma once
#include <iostream>
#include <string>
using namespace std;

class Content
{
private:
	string title;
	int ID;
public:
	Content(int ID = -5, string title = "");
	int getID();
};

#endif 
