/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#include "ContentCreator.h"
#include "Content.h"
#include <iostream>
#include <string>
#include "LinkedList.h"
#include "Node.h"
using namespace std;

ContentCreator::ContentCreator(int ID, string name) {
	this->ID = ID; 
	this->name = name;
} 

ContentCreator::~ContentCreator() {
	contents.clear();
	followers.clear();
} 

bool ContentCreator::addContent(int ID, string title) {
	bool added = false;
	Content c(ID, title);
	for (int k = 1; k <= this->contents.getLength(); k++) {
		if (contents.getNode(k)->getItem().getID() >= ID) { 
			contents.insert(k, c); 
			added = true;
			return true;
		}
	}
	if (contents.getLength() == 0) {
		contents.insert(1, c);
		added = true;
	}
	if (!added) {
		contents.insert(contents.getLength() + 1, c);
		return true;
	}
	return false;
}

bool ContentCreator::removeContent(int ID) {
	for (int i = 1; i <= contents.getLength(); i++) {
		if (contents.getNode(i)->getItem().getID() == ID) {
			contents.remove(i);
			cout << "Removed content " << ID << "." << endl;
			return true;
		}
	}
	cout << "Cannot remove content. There is no content with ID " << ID << " shared by content creator with ID " << this->getID() << "." << endl;
	return false;
}

bool ContentCreator::addFollower(int ID) {
	for (int i = 1; i <= followers.getLength(); i++) {
		if (followers.getNode(i)->getItem() == ID) {
			cout << "Cannot follow. The user is already following the content creator." << endl;
			return false;
		}
	}
	bool added = false;
	for (int k = 1; k <= followers.getLength(); k++) {
		if (followers.getNode(k)->getItem() >= ID) { 
			followers.insert(k, ID);
			cout << "Regular user with ID " << ID << " followed content creator with ID " << this->getID() << "." << endl;
			added = true;
			return true;
		}
	}
	if (followers.getLength() == 0) {
		followers.insert(1, ID);
		cout << "Regular user with ID " << ID << " followed content creator with ID " << this->getID() << "." << endl;
		added = true;
		return true;
	}
	if (!added) {
		followers.insert(followers.getLength() + 1, ID);
		cout << "Regular user with ID " << ID << " followed content creator with ID " << this->getID() << "." << endl;
		return true;
	}
	return false;
}

bool ContentCreator::removeFollower(int ID) {
	for (int i = 1; i <= followers.getLength(); i++) {
		if (followers.getNode(i)->getItem() == ID) {
			followers.remove(i);
			cout << "Regular user with ID " << ID << " unfollowed content creator with ID " << this->getID() << "." << endl;
			return true;
		}
	}
	cout << "Cannot unfollow. The user is not following the content creator." << endl;
	return false;
}

bool ContentCreator::removeFollowerDeleted(int ID) {
	for (int i = 1; i <= followers.getLength(); i++) {
		if (followers.getNode(i)->getItem() == ID) {
			followers.remove(i);
			return true;
		}
	}
	return false;
}

int ContentCreator::getID() {
	return ID;
}

string ContentCreator::getName() {
	return name;
}

void ContentCreator::showFollowers() {
	cout << "Regular users following content creator with ID " << this->getID() << ":" << endl;
	if (followers.getLength() == 0) {
		cout << "None" << endl;
	}
	else {
		for (int i = 1; i <= followers.getLength(); i++) {
			cout << followers.getNode(i)->getItem() << endl;
		}
	}
}

void ContentCreator::showContents() {
	cout << "Contents of content creator with ID " << this->getID() << ":" << endl;
	if (contents.getLength() == 0) {
		cout << "None" << endl;
	}
	else {
		for (int i = 1; i <= contents.getLength(); i++) {
			cout << contents.getNode(i)->getItem().getID() << endl;
		}
	}
}

int ContentCreator::getFollowerCount() {
	return followers.getLength();
}

int ContentCreator::getContentCount() {
	return contents.getLength();
}

LinkedList<Content>& ContentCreator::getContents() {
	return contents;
}