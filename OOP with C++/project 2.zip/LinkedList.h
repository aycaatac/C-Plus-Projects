/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef LINKED_LIST_
#define LINKED_LIST_

#pragma once
#include "Node.h"
#include <iostream>
#include <string>
using namespace std;

template <class ItemType>
class LinkedList
{
private:
	int itemCount;
	Node<ItemType>* headPtr;

public:
	LinkedList();
	~LinkedList();
	Node<ItemType>* getNode(int position) const;
	bool isEmpty() const;
	int getLength() const;
	void clear();
	bool remove(int position);
	bool insert(int position, const ItemType& item);
	ItemType& getEntry(int position) const;
};
#endif

template<class ItemType>
LinkedList<ItemType>::LinkedList() {
	itemCount = 0;
	headPtr = nullptr;
}

template<class ItemType>
LinkedList<ItemType>::~LinkedList() {
	clear();
}

template<class ItemType>
bool LinkedList<ItemType>::isEmpty() const {
	return itemCount == 0;
}

template<class ItemType>
int LinkedList<ItemType>::getLength() const {
	return itemCount;
}

template<class ItemType>
bool LinkedList<ItemType>::insert(int position, const ItemType& item) {
	bool appr = (position >= 1) && (position <= itemCount + 1);
	Node<ItemType>* ptr = new Node<ItemType>(item);
	if (appr) {
		if (position == 1 || headPtr == nullptr) {
			ptr->setNext(headPtr);
			headPtr = ptr;
		}
		else {
			Node<ItemType>* prev = getNode(position - 1);
			ptr->setNext(prev->getNext());
			prev->setNext(ptr);
		}
		itemCount++;
	}
	return appr;
}

template<class ItemType>
bool LinkedList<ItemType>::remove(int position) {
	bool appr = (position >= 1) && (position <= itemCount);
	if (appr) {
		Node<ItemType>* ptr = nullptr;
		if (position == 1) {
			ptr = headPtr;
			headPtr = headPtr->getNext();
		}
		else {
			Node<ItemType>* prev = getNode(position - 1);
			ptr = prev->getNext();
			prev->setNext(ptr->getNext());
		}
		ptr->setNext(nullptr);
		delete ptr;
		ptr = nullptr;
		itemCount--;
	}
	return appr;
}

template<class ItemType>
Node<ItemType>* LinkedList<ItemType>::getNode(int position) const {
	if ((position >= 1) && (position <= itemCount)) {
		Node<ItemType>* ptr = headPtr;
		for (int i = 1; i < position; i++) {
			ptr = ptr->getNext();
		}
		return ptr;
	}
	return nullptr;
}

template<class ItemType>
void LinkedList<ItemType>::clear() {
	while (!isEmpty()) {
		remove(1);
	}
}

template<class ItemType>
ItemType& LinkedList<ItemType>::getEntry(int position) const{
	bool appr = (position >= 1) && (position <= itemCount);
	if (appr) {
		Node<ItemType>* node = getNode(position);
		return (node->getItem());
	}
	return headPtr->getItem();
}