/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */
#ifndef CREATOR_
#define CREATOR_

#pragma once
#include <iostream>
#include <string>
#include "LinkedList.h"
#include "Content.h"
#include "Node.h"
using namespace std;
class ContentCreator
{
private:
	int ID;
	string name;
	LinkedList<int> followers;
	LinkedList<Content> contents;

public:
	ContentCreator(int ID = -5, string name = "");
	~ContentCreator();
	bool addContent(int ID, string title);
	bool removeContent(int ID);
	bool addFollower(int ID);
	bool removeFollower(int ID);
	bool removeFollowerDeleted(int ID);
	int getID();
	string getName();
	void showContents();
	void showFollowers();
	int getFollowerCount();
	int getContentCount();
	LinkedList<Content>& getContents();
};

#endif

