/*Name: Ayca Candan Atac
  Section: 002
  ID: 22203501 */

#include "User.h"


User::User(int ID, string name) {
	this->ID = ID;
	this->name = name;
}

int User::getID() {
	return ID;
}

string User::getName() {
	return name;
}
