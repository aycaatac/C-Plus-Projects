#include <iostream>
#include <string>
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <chrono>
#include <iomanip>
using namespace std;


int* generate_random_array(int size) { 
	srand((unsigned int)time(NULL));
	int* my_array = new int[size];
	for (int i = 0; i < size; i++) {
		my_array[i] = rand();
	}
	return my_array;
}
int* generate_almost_sorted_array(int size) {
	srand((unsigned int)time(NULL));
	int* my_array = new int[size];
	for (int i = 0; i < size; i++) {
		my_array[i] = i;
		if (std::rand() % 10 == 1) {
			my_array[i] = i + size;
		}
	}
	return my_array;
}
int* generate_ascending_array(int size) {
	int* my_array = new int[size];
	for (int i = 0; i < size; i++) {
		my_array[i] = i;
	}
	return my_array;
}

int* generate_descending_array(int size) {
	int* my_array = new int[size];
	int a = 0;
	for (int i = size - 1; i >= 0 && a < size; i--) {
		my_array[a] = i;
		a++;
	}
	return my_array;
}

void bubbleSort(int theArray[], int n) {
	bool sorted = false;
	for (int pass = 1; (pass < n) && !sorted; ++pass) {
		sorted = true;
		for (int index = 0; index < n - pass; ++index) {
			int nextIndex = index + 1;
			if (theArray[index] > theArray[nextIndex]) {
				swap(theArray[index], theArray[nextIndex]);
				sorted = false;
			}
		}
	}
}

int mergeSize = 0;
int memCounter = 0;
void merge(int theArray[], int first, int mid, int last) {
	mergeSize = last - first + 1;
	memCounter += mergeSize * 4;
	int* tempArray = new int[mergeSize]; // temporary array
	int first1 = first; // beginning of first subarray
	int last1 = mid; // end of first subarray
	int first2 = mid + 1; // beginning of second subarray
	int last2 = last; // end of second subarray
	int index = first1; // next available location in tempArray
	for (; ((first1 <= last1) && (first2 <= last2)) && index < mergeSize; ++index) {
		if (theArray[first1] < theArray[first2]) {
			tempArray[index] = theArray[first1];
			++first1;
		}
		else {
			tempArray[index] = theArray[first2];
			++first2;
		}
	}
	for (; first1 <= last1 && index < mergeSize; ++first1, ++index)
		tempArray[index] = theArray[first1];
	// finish off the second subarray, if necessary
	for (; first2 <= last2 && index < mergeSize; ++first2, ++index)
		tempArray[index] = theArray[first2];
	// copy the result back into the original array
	for (index = first; index <= last && index < mergeSize; ++index)
		theArray[index] = tempArray[index];

	delete[] tempArray;
}

void mergesort(int theArray[], int first, int last) {
	if (first < last) {
		int mid = (first + last) / 2; // index of midpoint
		mergesort(theArray, first, mid);
		mergesort(theArray, mid + 1, last);
		// merge the two halves
		merge(theArray, first, mid, last);
	}
}

void partition(int theArray[], int first, int last, int& pivotIndex) {
	// Precondition: theArray[first..last] is an array; first <= last.
	// Postcondition: Partitions theArray[first..last] such that:
	// S1 = theArray[first..pivotIndex-1] < pivot
	// theArray[pivotIndex] == pivot
	// S2 = theArray[pivotIndex+1..last] >= pivot
	// place pivot in theArray[first]
	int pivot = theArray[first];
	// initially, everything but pivot is in unknown
	int lastS1 = first; // index of last item in S1
	int firstUnknown = first + 1; // index of first item in unknown
	// move one item at a time until unknown region is empty
	for (; firstUnknown <= last; ++firstUnknown) {
		// Invariant: theArray[first+1..lastS1] < pivot
		// theArray[lastS1+1..firstUnknown-1] >= pivot
		// move item from unknown to proper region
		if (theArray[firstUnknown] < pivot) { // belongs to S1
			++lastS1;
			swap(theArray[firstUnknown], theArray[lastS1]);
		} // else belongs to S2
	}
	// place pivot in proper position and mark its location
	swap(theArray[first], theArray[lastS1]);
	pivotIndex = lastS1;
}

void quicksort(int theArray[], int first, int last) {
	// Precondition: theArray[first..last] is an array.
	// Postcondition: theArray[first..last] is sorted.
	int pivotIndex;
	if (first < last) {
		// create the partition: S1, pivot, S2
		partition(theArray, first, last, pivotIndex);
		// sort regions S1 and S2
		quicksort(theArray, first, pivotIndex - 1);
		quicksort(theArray, pivotIndex + 1, last);
	}
}


int main() {
	chrono::duration<double> durResult;
	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Bubble Sort for almost sorted array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_almost_sorted_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			bubbleSort(arr1, arrsize);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Quick Sort for almost sorted array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_almost_sorted_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			quicksort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Merge Sort for almost sorted array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_almost_sorted_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			mergesort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Merge Sort for sorted (ascending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_ascending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			mergesort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Merge Sort for sorted (descending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_descending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			mergesort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}
	
	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Merge Sort for random array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_random_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			mergesort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Quick Sort for sorted (ascending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_ascending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			quicksort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Quick Sort for sorted (descending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_descending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			quicksort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Quick Sort for random array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_random_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			quicksort(arr1, 0, arrsize - 1);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Bubble Sort for sorted (ascending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_ascending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			bubbleSort(arr1, arrsize);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Bubble Sort for sorted (descending) array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_descending_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			bubbleSort(arr1, arrsize);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}

	for (int k = 3; k < 13; k++) {
		memCounter = 0;
		const int arrsize = pow(2, k);
		cout << endl;
		cout << "Bubble Sort for random array with size 2^" << k << ": " << endl;
		for (int i = 0; i < 10; i++) {
			int* arr1 = generate_random_array(arrsize);
			auto start_time = chrono::high_resolution_clock::now();
			bubbleSort(arr1, arrsize);
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			if (i == 0) {
				durResult = duration;
			}
			else {
				durResult += duration;
			}
			delete[] arr1;
		}
		cout << "Time passed in seconds: " << durResult.count() / 10.0 << endl;
		cout << "Memory used in bytes: " << memCounter << endl;
	}
	return 0;
}