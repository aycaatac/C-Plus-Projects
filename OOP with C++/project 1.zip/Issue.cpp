//Ayca Candan Atac 22203501 Section 2
#include <iostream>
#include <string>
using namespace std;
#include "Issue.h"

Issue::Issue(const int issueId, const string description, const string
	assigneeName) {
	issueID = issueId;
	issueDescription = description;
	issueAssignee = assigneeName;
}

Issue::~Issue() {
	issueAssignee = "";
	issueDescription = "";
	issueID = -1;
}

int Issue::getId() {
	return issueID;
}

string Issue::getDescription() {
	return issueDescription;
}

string Issue::getAssignee() {
	return issueAssignee;
}

void Issue::setAssignee(string name) {
	issueAssignee = name;
}