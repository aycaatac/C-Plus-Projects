//Ayca Candan Atac 22203501 Section 2
#ifndef _EMPLOYEE_H
#define _EMPLOYEE_H
#include <iostream>
#include <string>
using namespace std;
#include "Issue.h"
class Employee
{
public:
	Employee(string name = "", string title = "");
	~Employee();
	string getName();
	string getTitle();
	int getEmployeeIssueCount();
	Issue* getEmployeeIssues();
	void setEmployeeIssueCount(int no);
	void setEmployeeIssues(Issue* i);
	bool addIssueEmployee(Issue& i);
	bool removeIssueEmployee(int issueID);
	Employee& operator=(const Employee& other);

private:
	string employeeName;
	string employeeTitle;
	int employeeIssueCount;
	Issue* employeIssues;
};
#endif
