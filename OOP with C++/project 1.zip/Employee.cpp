//Ayca Candan Atac 22203501 Section 2
#include <iostream>
#include <string>
using namespace std;
#include "Employee.h"

Employee::Employee(string name, string title) {
	employeeName = name;
	employeeTitle = title;
	employeeIssueCount = 0;
	employeIssues = nullptr;
	
}

Employee::~Employee() {
	
	if (employeeIssueCount > 0) {
		delete[] employeIssues;
		employeIssues = nullptr;
		}
	
}

Employee& Employee::operator=(const Employee& other)
{
	if (this == &other)
	{
		return *this;
	}

	employeeName = other.employeeName;
	employeeTitle = other.employeeTitle;
	employeeIssueCount = other.employeeIssueCount;

	Issue* oldArr = this->employeIssues;

	if (other.employeIssues)
	{
		employeIssues = new Issue[employeeIssueCount];
		for (int i = 0; i < employeeIssueCount; i++)
		{
			employeIssues[i] = other.employeIssues[i];
		}
	}
	else
	{
		employeIssues = nullptr;
	}

	delete[] oldArr;
	return *this;
}

string Employee::getName() {
	return employeeName;
}

string Employee::getTitle() {
	return employeeTitle;
}

int Employee::getEmployeeIssueCount() {
	return employeeIssueCount;
}

Issue* Employee::getEmployeeIssues() {
	return employeIssues;
}

void Employee::setEmployeeIssueCount(int count) {
	employeeIssueCount = count;
}

void Employee::setEmployeeIssues(Issue* i) {
	employeIssues = i;
}


bool Employee::removeIssueEmployee(int issueID) {
	bool issueChecked = false;
	for (int i = 0; i < employeeIssueCount; i++) {
		if (employeIssues[i].getId() == issueID) {
			issueChecked = true;
		}
	}
	if (!issueChecked) { return false; }
	Issue* temp = new Issue[employeeIssueCount - 1];
	int indexFor = 0;
	for (int k = 0; k < employeeIssueCount && indexFor < employeeIssueCount - 1; k++) {
		if (employeIssues[k].getId() != issueID) {
			temp[indexFor] = employeIssues[k];
			indexFor++;
		}
	}
	employeeIssueCount--;
	delete[] employeIssues;
	employeIssues = temp;
	issueChecked = false;
	for (int r = 0; r < employeeIssueCount; r++) {
		if (employeIssues[r].getId() == issueID) {
			issueChecked = true;
			return false;
		}
	}
	if (employeeIssueCount == 0) {
		return true;
	}
	if (!issueChecked) { return true; }
	return true;
}

bool Employee::addIssueEmployee(Issue& i) {
	Issue* temp = new Issue[employeeIssueCount + 1];
	for (int u = 0; u < employeeIssueCount; u++) {
		temp[u] = employeIssues[u];
	}
	temp[employeeIssueCount] = i;
	delete[] employeIssues;
	employeIssues = temp;
	employeeIssueCount++;
	for (int r = 0; r < employeeIssueCount; r++) {
		if (employeIssues[r].getId() == i.getId()) {
			return true;
		}
	}
	if (employeeIssueCount == 0) {
		return false;
	}
	return false;
}

