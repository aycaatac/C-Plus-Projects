//Ayca Candan Atac 22203501 Section 2
#include <iostream>
#include <string>
using namespace std;
#include "IssueTrackingSystem.h"

IssueTrackingSystem::IssueTrackingSystem() {
	employeeCount = 0;
	issueCount = 0;
	employeeList = nullptr;
	issueList = nullptr;
}

IssueTrackingSystem::~IssueTrackingSystem() {
	if (issueCount > 0) {
		delete[] issueList;
		issueList = nullptr;
	}
	if (employeeCount > 0) {
		delete[] employeeList;
		employeeList = nullptr;
	}
	issueCount = 0;
	employeeCount = 0;
}

void IssueTrackingSystem::showIssue(const int ID) const {
	bool found = false;
	for (int i = 0; i < issueCount; i++) {
		if (issueList[i].getId() == ID) {
			found = true;
			cout << issueList[i].getId() << ", " << issueList[i].getDescription() << ", " << issueList[i].getAssignee() << "." << endl;
		}
	}
	if (!found) {
		cout << "Cannot show issue. There is no issue with ID " << ID << "." << endl;
	}
}

void IssueTrackingSystem::showEmployee(const string name) const {//writing const here?? does const affect anything??
	bool found = false;
	for (int u = 0; u < employeeCount; u++) {
		if (employeeList[u].getName() == name) {
			found = true;
			cout << employeeList[u].getName() << ", " << employeeList[u].getTitle() << ", " << employeeList[u].getEmployeeIssueCount() << " issue(s)." << endl;
		}
	}
	if (!found) {
		cout << "Cannot show employee. There is no employee with name " << name << "." << endl;
	}
}

void IssueTrackingSystem::showAllIssues() const {
	if (issueCount == 0) {
		cout << "Issues in the system:" << endl;
		cout << "None" << endl;
	}
	else {
		cout << "Issues in the system:" << endl;
		for (int i = 0; i < employeeCount; i++) {
			if (employeeList[i].getEmployeeIssueCount() != 0) {
				for (int y = 0; y < employeeList[i].getEmployeeIssueCount(); y++) {
					cout << employeeList[i].getEmployeeIssues()[y].getId() << ", " << employeeList[i].getEmployeeIssues()[y].getDescription() << ", " << employeeList[i].getName() << "." << endl;
				}
			}
		}
	}
}

void IssueTrackingSystem::showAllEmployees() const {
	if (employeeCount == 0) {
		cout << "Employees in the system:" << endl;
		cout << "None" << endl;
	}
	else {
		cout << "Employees in the system:" << endl;
		for (int r = 0; r < employeeCount; r++) {
			showEmployee(employeeList[r].getName());
		}
	}
}

void IssueTrackingSystem::addEmployee(const string name, const string title) {
	bool found = false;
	for (int i = 0; i < employeeCount; i++) {
		if (employeeList[i].getName() == name) {
			found = true;
			cout << "Cannot add employee. Employee with name " << name << " already exists." << endl;
		}
	}
	if (!found) {
		Employee* temp = new Employee[employeeCount + 1];
		for (int h = 0; h < employeeCount; h++) {
			temp[h] = employeeList[h];
		}
		Employee e(name, title);
		temp[employeeCount] = e;
		delete[] employeeList;
		employeeList = temp;
		employeeCount++;
		cout << "Added employee " << name << "." << endl;
	}
}

void IssueTrackingSystem::addIssue(const int issueId, const string description, const string
	assigneeName) {

	bool found = false;
	int employeeIndex = -1;
	for (int i = 0; i < employeeCount; i++) {
		if (employeeList[i].getName() == assigneeName) {
			found = true;
			employeeIndex = i;
		}
	}
	if (!found) {
		cout << "Cannot add issue. There is no employee with name " << assigneeName << "." << endl;
	}
	if (found) {
		found = false;
		for (int f = 0; f < issueCount; f++) {
			if (issueList[f].getId() == issueId) {
				found = true;
				cout << "Cannot add issue. Issue with ID " << issueId << " already exists." << endl;
			}
		}
		if (!found) {
			Issue newIssue(issueId, description, assigneeName);
			employeeList[employeeIndex].addIssueEmployee(newIssue);
			Issue* temp = new Issue[issueCount + 1];
			for (int i = 0; i < issueCount; i++) {
				temp[i] = issueList[i];
			}
			temp[issueCount] = newIssue;
			delete[] issueList;
			issueList = temp;
			issueCount++;
			cout << "Added issue " << issueId << "." << endl;
		}
	}
	
}

void IssueTrackingSystem::removeIssue(const int issueId) {
	bool found = false;
	for (int r = 0; r < issueCount; r++) {
		if (issueList[r].getId() == issueId) {
			found = true;
		}
	}
	if (!found) {
		cout << "Cannot remove issue. There is no issue with ID " << issueId << "." << endl;
	}
	if (found) {
		for (int h = 0; h < employeeCount; h++) {//direkt issue id den gidebilirdik
			for (int y = 0; y < employeeList[h].getEmployeeIssueCount(); y++) {
				if (employeeList[h].getEmployeeIssues()[y].getId() == issueId) {
					employeeList[h].removeIssueEmployee(issueId);
				}
			}
		}
		Issue* temp = new Issue[issueCount - 1];
		int indexFor = 0;
		for (int i = 0; i < issueCount; i++) {
			if (issueList[i].getId() != issueId) {
				temp[indexFor] = issueList[i];
				indexFor++;
			}
		}
		delete[] issueList;
		issueList = temp;
		issueCount--;
		cout << "Removed issue " << issueId << "." << endl;
	}
}

void IssueTrackingSystem::removeEmployee(const string name) {
	bool found = false;
	int employeeIndex = -1;
	for (int e = 0; e < employeeCount; e++) {
		if (employeeList[e].getName() == name) {
			found = true;
			employeeIndex = e;
		}
	}
	if (!found) {
		cout << "Cannot remove employee. There is no employee with name " << name << "." << endl;
	}
	if (found) {
		if (employeeList[employeeIndex].getEmployeeIssueCount() != 0) {
			cout << "Cannot remove employee. " << name << " has assigned issues." << endl;
		}
		else {
			Employee* temp = new Employee[employeeCount - 1];
			int indexFor = 0;
			for (int g = 0; g < employeeCount; g++) {
				if (employeeList[g].getName() != name) {
					temp[indexFor] = employeeList[g];
					indexFor++;
				}
			}
			delete[] employeeList;
			employeeList = temp;
			employeeCount--;
			cout << "Removed employee " << name << "." << endl;
		}
	}
}

void IssueTrackingSystem::changeAssignee(const string previousAssignee, const string newAssignee) {
	bool found1 = false;
	bool found2 = false;
	int index1 = 0;
	int index2 = 0;

	for (int i = 0; i < employeeCount; i++) {
		if (employeeList[i].getName() == previousAssignee) {
			found1 = true;
			index1 = i;
		}
		if (employeeList[i].getName() == newAssignee) {
			found2 = true;
			index2 = i;
		}
	}
	if (!found1 || !found2) {
		cout << "Cannot change assignee. Previous or/and new assignee does not exist." << endl;
	}
	if (found1 && found2) {
		for (int y = 0; y < employeeList[index1].getEmployeeIssueCount(); y++) {
			for (int k = 0; k < issueCount; k++) {
				if (employeeList[index1].getEmployeeIssues()[y].getId() == issueList[k].getId()) {
					issueList[k].setAssignee(employeeList[index2].getName());
				}
			}
			employeeList[index2].addIssueEmployee(employeeList[index1].getEmployeeIssues()[y]);
			employeeList[index1].removeIssueEmployee(employeeList[index1].getEmployeeIssues()[y].getId());

		}
		cout << previousAssignee << "'s issues are transferred to " << newAssignee << "." << endl;
	}
}