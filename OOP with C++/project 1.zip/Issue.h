//Ayca Candan Atac 22203501 Section 2
#ifndef _ISSUE_H
#define _ISSUE_H

#include <iostream>
#include <string>
using namespace std;



class Issue
{
public:
	Issue(const int issueId = 0, const string description = "", const string
		assigneeName = "");
	~Issue();
	int getId();
	string getAssignee();
	string getDescription();
	void setAssignee(string name);
private:
	int issueID;
	string issueDescription;
	string issueAssignee;
};

#endif