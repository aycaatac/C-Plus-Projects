/**
* Title: Binary Search Trees
* Author : Ayca Candan Atac
* ID: 22203501
* Section : 1
* Homework : 1
* Description : header file of the analysis class for the report
*/

#ifndef ANALYSIS_H_
#define ANALYSIS_H_

#pragma once
class analysis
{

public:
	void timeAnalysis();
	int* createArray();
};

#endif