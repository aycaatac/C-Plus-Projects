/**
* Title: Binary Search Trees
* Author : Ayca Candan Atac
* ID: 22203501
* Section : 1
* Homework : 1
* Description : header file of the bst class
*/
#ifndef BST_H_
#define BST_H_
#pragma once
#include "Node.h"

class BST
{

public:
	BST();
	BST(int keys[], int size);
	~BST();
	void insertKey(int key);
	void maximumSumPath();
	void maximumWidth();
	void insert(Node<int>*& ptr, int key);
	void deleteKey(int key);
	void deleteItem(Node<int>*& treePtr, int key);
	void deleteHelper(Node<int>*& nodePtr);
	void displayInorder();
	void processLeftmost(Node<int>*& nodePtr, int& item);
	void findFullBTLevel();
	int findFullBTLevelHelper(Node<int>* treePtr, int level);
	void lowestCommonAncestor(int A, int B);
	void pathFromAtoB(int A, int B);
	int getHeight(Node<int>* ptr);
	bool search(Node<int>* treePtr, int key);
	bool keyExists(int key);
	void inorderTraverse();
	typedef void (*FunctionType)(int anItem, int count);
	typedef void (*FuncType)(Node<int>* ptr);
	void printPath(bool normal, int a, int b);
	int pathHelper(Node<int>* ptr, int A, int B);
	bool isAnAncestor(Node<int>* ancestor, int child);
	int lowestCommonAncestorHelper(Node<int>* nodePtr, int A, int B);
	void inorder(Node<int>* treePtr, FunctionType func);
	void clearPath();
	void inorderVisited(Node<int>* treePtr, FuncType func);
	void destroyTree(Node<int>*& treePtr);
	int max(int a, int b);
	void maximumSumPathHelper(Node<int>* ptr);

	Node<int>* root;
	int nodeCount;
	bool fromConst;
	bool inPath;
	int* path;
	int* pathForSum;
	int* pathForMaxSum;
	int pathElement;
	bool found;
	bool foundLowest;
	int commonAncestor;
	int maxPathSum;
	int currSum;
	int pathIndex;
	int elementCount;
};
#endif 
