/**
* Title: Binary Search Trees
* Author : Ayca Candan Atac
* ID: 22203501
* Section : 1
* Homework : 1
* Description : description of your code
*/
#ifndef NODE_
#define NODE_

#pragma once

template<class ItemType>

class Node
{
private:
	ItemType item;
	Node<ItemType>* leftChild;
	Node<ItemType>* rightChild;
	bool visited;
	Node<ItemType>* next;

public:
	Node();
	Node(const ItemType& item, Node<ItemType>* left, Node<ItemType>* right);
	void setRightChild(Node<ItemType>* right);
	void setLeftChild(Node<ItemType>* left);
	Node(const ItemType& item);
	void setItem(ItemType item);
	const ItemType& getItem() const;
	ItemType& getItem();
	Node<ItemType>*& getLeftChild() ;
	Node<ItemType>*& getRightChild() ;
	bool hasUnvisitedRight(Node<ItemType>* ptr);
	bool hasUnvisitedLeft(Node<ItemType>* ptr);
	void setNext(Node<ItemType>* nextNode);
	bool isVisited();
	void setVisited(bool a);
	Node<ItemType>* getNext() const;
	bool added;
};

#endif 

template <class ItemType>
Node<ItemType>::Node(const ItemType& item) {
	this->item = item;
	this->next = nullptr;
}

template <class ItemType>
Node<ItemType>::Node() {
	this->next = nullptr;
	added = false;
	visited = false;
}

template <class ItemType>
Node<ItemType>::Node(const ItemType& item, Node<ItemType>* left, Node<ItemType>* right) {
	this->item = item;
	this->leftChild = left;
	this->rightChild = right;
	visited = false;
}

template <class ItemType>
bool Node<ItemType>::isVisited() {
	return visited;
}

template<class ItemType>
void Node<ItemType>::setVisited(bool a)
{
	this->visited = a;
}

template<class ItemType>
void Node<ItemType>::setLeftChild(Node<ItemType>* left)
{
	this->leftChild = left;
}

template<class ItemType>
void Node<ItemType>::setItem(ItemType itemN)
{
	this->item = itemN;
}

template<class ItemType>
void Node<ItemType>::setRightChild(Node<ItemType>* right)
{
	this->rightChild = right;
}

template <class ItemType>
const ItemType& Node<ItemType>::getItem() const {
	return item;
}

template <class ItemType>
ItemType& Node<ItemType>::getItem() {
	return item;
}

template <class ItemType>
Node<ItemType>*& Node<ItemType>::getLeftChild() {
	return leftChild;
}

template <class ItemType>
Node<ItemType>*& Node<ItemType>::getRightChild() { //was the & a mistake for this and above. i also deleted const from these
	return rightChild;
}

template<class ItemType>
bool Node<ItemType>::hasUnvisitedRight(Node<ItemType>* ptr)
{
	if (ptr->getRightChild() == nullptr) {
		return false;
	}
	else {
		if (!ptr->getRightChild()->isVisited()) {
			return true;
		}
		return false;
	}
}

template<class ItemType>
bool Node<ItemType>::hasUnvisitedLeft(Node<ItemType>* ptr)
{
	if (ptr->getLeftChild() == nullptr) {
		return false;
	}
	else {
		if (!ptr->getLeftChild()->isVisited()) {
			return true;
		}
		return false;
	}
}

template <class ItemType>
Node<ItemType>* Node<ItemType>::getNext() const {
	return next;
}

template <class ItemType>
void Node<ItemType>::setNext(Node<ItemType>* nexth) {
	this->next = nexth;
}

