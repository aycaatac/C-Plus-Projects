/**
* Title: Binary Search Trees
* Author : Ayca Candan Atac
* ID: 22203501
* Section : 1
* Homework : 1
* Description : implementation file of the bst class
*/

#include "BST.h"
#include <string>
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <chrono>
#include <iomanip>
#include <cstdlib>
#include <iostream>
using namespace std;


//default constructor
BST::BST()
{
	elementCount = 0;
	pathIndex = 0;
	fromConst = false;
	inPath = false;
	nodeCount = 0;
	pathElement = 0;
	found = false;
	foundLowest = false;
	commonAncestor = 0;
	path = nullptr;
	pathForSum = nullptr;
	pathForMaxSum = nullptr;
	currSum = 0;
	maxPathSum = 0;
	root = new Node<int>(-1111, nullptr, nullptr);
}

//constructor-we can assume the keys are unique
BST::BST(int keys[], int size) { 
	fromConst = false;
	elementCount = 0;
	pathIndex = 0;
	inPath = false;
	nodeCount = 0;
	pathElement = 0;
	found = false;
	foundLowest = false;
	commonAncestor = 0;
	path = new int[size];
	for (int y = 0; y < size; y++) {
		path[y] = 0;
	}
	pathForSum = new int[size];
	pathForMaxSum = new int[size];
	currSum = 0;
	maxPathSum = 0;
	if (size == 0) {
		root = new Node<int>(-1111, nullptr, nullptr);
	}
	else {
		
		root = new Node<int>(keys[0], nullptr, nullptr);
		nodeCount++;

		for (int i = 1; i < size; i++) {
			fromConst = true;
			insertKey(keys[i]);
		}
		cout << "BST with size " << nodeCount << " is created." << endl; //bunun burda olmas� normal mi 
	}
}

//destroys the tree by recursion
void BST::destroyTree(Node<int>*& treePtr) {

	if (treePtr != nullptr) {
		destroyTree(treePtr->getLeftChild());
		destroyTree(treePtr->getRightChild());
		delete treePtr;
		treePtr = nullptr;
	}
}

//destructor
BST::~BST()
{
	destroyTree(root);
	if (path != nullptr) {
		delete[] path;
		path = nullptr;
	}
	if (pathForSum != nullptr) {
		delete[] pathForSum;
		pathForSum = nullptr;
	}
	if (pathForMaxSum != nullptr) {
		delete[] pathForMaxSum;
		pathForMaxSum = nullptr;
	}
	commonAncestor = 0;
}

//insert key funciton
void BST::insertKey(int key)
{
	insert(root, key);
	fromConst = false;
}

//helps to insert the given key to the fitted place by recursion
void BST::insert(Node<int>*& ptr, int key) 
{
	bool exists = search(root, key);
	if (ptr == nullptr) {
		ptr = new Node<int>(key, nullptr, nullptr);
		if (!fromConst) { 
			cout << "Key " << key << " is added." << endl;
		}
		nodeCount++;
	}
	else if (exists) {
		cout << "Key " << key << " is not added. It exists!" << endl;
	}
	else {
		if (ptr == nullptr) {
			ptr = new Node<int>(key, nullptr, nullptr);
		}
		else if (key < ptr->getItem()) {
			insert(ptr->getLeftChild(), key);
		}
		else {
			insert(ptr->getRightChild(), key);
		}
	}
}

//deletes the given key
void BST::deleteKey(int key)
{
	bool exists = search(root, key);
	if (!exists) {
		cout << "Key " << key << " is not deleted. It does not exist!" << endl;
	}
	else {
		deleteItem(root, key);
		cout << "Key " << key << " is deleted." << endl;
		nodeCount--;
	}
}

//finds the given key's node by recursion
void BST::deleteItem(Node<int>*& treePtr, int key)
{
	if (key == treePtr->getItem()) {
		deleteHelper(treePtr);
	}
	else if (key < treePtr->getItem()) {
		deleteItem(treePtr->getLeftChild(), key);
	}
	else {
		deleteItem(treePtr->getRightChild(), key);
	}
}

//deletes the found node
void BST::deleteHelper(Node<int>*& nodePtr)
{
	Node<int>* delPtr;
	int replacement;

	if ((nodePtr->getLeftChild() == nullptr) && (nodePtr->getRightChild() == nullptr)) {//leftchild ptrnin nullptr olmas�yla iteminin null olmas� ayn� sey mi
		delete nodePtr;
		nodePtr = nullptr;
	}

	else if (nodePtr->getLeftChild() == nullptr) {
		delPtr = nodePtr;
		nodePtr = nodePtr->getRightChild();
		delPtr->setRightChild(nullptr);
		delete delPtr;
	}

	else if (nodePtr->getRightChild() == nullptr) {
		delPtr = nodePtr;
		nodePtr = nodePtr->getLeftChild();
		delPtr->setLeftChild(nullptr);
		delete delPtr;
	}

	else {
		processLeftmost(nodePtr->getRightChild(), replacement);
		nodePtr->setItem(replacement);
	}
}

//finds the node to be inserted after a node with two childs is deleted
void BST::processLeftmost(Node<int>*& nodePtr, int& item)
{
	if (nodePtr->getLeftChild() == nullptr) {
		item = nodePtr->getItem();
		Node<int>* delPtr = nodePtr;
		nodePtr = nodePtr->getRightChild();
		delPtr->setRightChild(nullptr); // defense
		delete delPtr;
	}
	else {
		processLeftmost(nodePtr->getLeftChild(), item);
	}
}

//finds the level which is full on the level and the levels less than the founded level
void BST::findFullBTLevel()
{
	if (root == nullptr) {
		cout << "Full binary tree level is: 0" << endl;
	}
	else {
		int resultLevel = findFullBTLevelHelper(root, 2);
		cout << "Full binary tree level is: " << resultLevel << endl;
	}
}


//helps to find the full binary tree level by recursion
int BST::findFullBTLevelHelper(Node<int>* treePtr, int level)
{
	if (treePtr == nullptr) {
		if (treePtr == root) {
			return 0;
		}
		return level - 1;
	}

	if (!((treePtr->getLeftChild() != nullptr) && ((treePtr->getRightChild() != nullptr)))) {
		return level - 1;
	}
	int a;
	a = findFullBTLevelHelper(treePtr->getLeftChild(), level + 1);
	a = findFullBTLevelHelper(treePtr->getRightChild(), level + 1);
	return a; 
}

//finds the lowest common ancestor of two keys
void BST::lowestCommonAncestor(int A, int B)
{
	commonAncestor = 0;
	lowestCommonAncestorHelper(root, A, B);
	cout << "Lowest common ancestor of " << A << " and " << B << " is: " << commonAncestor << endl;
}

//helps to find the lowest common ancestor of two keys by recursion
int BST::lowestCommonAncestorHelper(Node<int>* nodePtr, int A, int B)
{
	found = false;
	bool a = isAnAncestor(nodePtr, A);
	bool b = isAnAncestor(nodePtr, B);
	if (a && b) {
		commonAncestor = nodePtr->getItem();
	}
	else {
		return 0;
	}
	if ((nodePtr->getLeftChild() == nullptr) && (nodePtr->getRightChild() == nullptr)) {//leftchild ptrnin nullptr olmas�yla iteminin null olmas� ayn� sey mi
		return 0;
	}

	else if (nodePtr->getLeftChild() == nullptr) {
		lowestCommonAncestorHelper(nodePtr->getRightChild(), A, B);
	}

	else if (nodePtr->getRightChild() == nullptr) {
		lowestCommonAncestorHelper(nodePtr->getLeftChild(), A, B);
	}

	else {
		found = false;
		lowestCommonAncestorHelper(nodePtr->getLeftChild(), A, B);
		found = false;
		lowestCommonAncestorHelper(nodePtr->getRightChild(), A, B);
	}
	return 0;
}

//returns the larger value, used for getHeight()
int BST::max(int a, int b) {
	if (b > a) {
		return b;
	}
	return a;
}

//prints the path from a to b if normal = true, if normal = false, prints from b to a 
void BST::printPath(bool normal, int A, int B)
{	

	if (normal) {
		int i = 0;
		while (path[i] != B) {
			
			cout << path[i] << ", ";
			i++;
		}
		int k = 0;
		while (path[k] != commonAncestor) {
			k++;
		}

		for (int c = k; c >= i; c--) {
			
			if (c != i) {
				cout << path[c] << ", ";
			}
			else {
				cout << path[c] << endl;
			}
		}
	}
	else {
		int i = 0;
		while (path[i] != B) {
			i++;
		}
		int k = 0;
		while (path[k] != commonAncestor) {
			k++;
		}

		for (int c = i; c <= k; c++) {
			cout << path[c] << ", ";
		}

		for (int j = i - 1; j >= 0; j--) {
			if (j != 0) {
				cout << path[j] << ", ";
			}
			else {
				cout << path[j] << endl;
			}
		}
	}
}


//helps to find the path from a to b by recursion
int BST::pathHelper(Node<int>* nodePtr, int A, int B)
{
	if (!(nodePtr->hasUnvisitedLeft(nodePtr)) && !(nodePtr->hasUnvisitedRight(nodePtr))) {
		nodePtr->setVisited(true);
		if ((nodePtr->getItem() == A) || (nodePtr->getItem() == B)) {
			inPath = true;
		}
		if (inPath) {
			found = false;
			if ((isAnAncestor(nodePtr, A) || isAnAncestor(nodePtr, B)) && !nodePtr->added) {
				path[pathElement] = nodePtr->getItem();
				pathElement++;
				nodePtr->added = true;
				
			}
		}
		return 0;
	}

	else if (!(nodePtr->hasUnvisitedRight(nodePtr))) {
		pathHelper(nodePtr->getLeftChild(), A, B);
		pathHelper(nodePtr, A, B);
	}

	else if (!(nodePtr->hasUnvisitedLeft(nodePtr))) {
		pathHelper(nodePtr->getRightChild(), A, B);
		pathHelper(nodePtr, A, B);
	}

	else {
		pathHelper(nodePtr->getLeftChild(), A, B);
		pathHelper(nodePtr, A, B);
		pathHelper(nodePtr->getRightChild(), A, B);

	}
	return 0;
}

//checks whether the node is the ancestor of the given key child
bool BST::isAnAncestor(Node<int>* ptr, int child)
{
	bool a;
	if (ptr->getItem() == child) {
		found = true;
		return true;
	}

	if ((ptr->getLeftChild() == nullptr) && (ptr->getRightChild() == nullptr)) {//leftchild ptrnin nullptr olmas�yla iteminin null olmas� ayn� sey mi
		return false;
	}

	else if (ptr->getLeftChild() == nullptr) {
		a = isAnAncestor(ptr->getRightChild(), child);
	}

	else if (ptr->getRightChild() == nullptr) {
		a = isAnAncestor(ptr->getLeftChild(), child);
	}

	else {
		found = false;
		a = isAnAncestor(ptr->getLeftChild(), child);
		if (!found) {
			a = isAnAncestor(ptr->getRightChild(), child);
		}
	}
	return a;
}

//resets the node's variables for next traversals
typedef void (*FuncType)(Node<int>* ptr);

void resetVisited(Node<int>* ptr)
{	
	ptr->added = false;
	ptr->setVisited(false);
}

//finds path from a to b
void BST::pathFromAtoB(int A, int B)
{	
	cout << "Path from " << A << " to " << B << " is: ";
	pathElement = 0;
	inPath = false;
	bool normal = true;
	if (A > B) {
		int temp = B;
		B = A;
		A = temp;
		normal = false;
	}
	pathHelper(root, A, B);
	lowestCommonAncestorHelper(root, A, B);
	printPath(normal, A, B);
	clearPath();
	inorderVisited(root, resetVisited);
}

//returns the height of the bst
int BST::getHeight(Node<int>* ptr)
{
	int height = 0;
	if (ptr == nullptr) {
		height = 0;
	}
	else {
		height = 1 + max(getHeight(ptr->getLeftChild()), getHeight(ptr->getRightChild()));
	}
	return height;
}

//returns whether the key exists in the tree or not
bool BST::search(Node<int>* treePtr, int key)
{
	bool a;
	if (treePtr == nullptr)
	{
		a = false;
	}
	else if (key == treePtr->getItem()) {
		a = true;
	}
	else if (key < treePtr->getItem()) {
		a = search(treePtr->getLeftChild(), key);
	}
	else {
		a = search(treePtr->getRightChild(), key);
	}
	return a;
}

//returns whether the key exists in the tree or not (the name is more suitable)
bool BST::keyExists(int key)
{
	bool exists = search(root, key);
	if (exists) {
		return true;
	}
	else {
		return false;
	}
}

//displays the bst with inorder traversal
void BST::displayInorder()
{
	cout << "Inorder display is: ";
	inorderTraverse();
}

//prints every node that has been visited
typedef void (*FunctionType)(int, int);

void visit(int item, int count) {
	if (count == 0) {
		cout << item << endl;
	}
	else {
		cout << item << ", ";
	}
}

//traverses with inorder traversal through the bst
void BST::inorderTraverse() {
	int count = nodeCount;
	inorder(root, visit); 
	nodeCount = count;
}

//helps to traverse the bst with inorder traversal by recursion
void BST::inorder(Node<int>* treePtr, FunctionType func) {
	if (treePtr != nullptr) {
		inorder(treePtr->getLeftChild(), visit);
		nodeCount--;
		visit(treePtr->getItem(), nodeCount);
		inorder(treePtr->getRightChild(), visit);
	}
}

//resets all of the node's variables for traversals
void BST::inorderVisited(Node<int>* treePtr, FuncType func) {
	if (treePtr != nullptr) {
		inorderVisited(treePtr->getLeftChild(), resetVisited);
		nodeCount--;
		resetVisited(treePtr);
		inorderVisited(treePtr->getRightChild(), resetVisited);
	}
}

//clears the paths for next traversals
void BST::clearPath()
{	
	for (int i = 0; i < nodeCount; i++) {
		path[i] = 0;
	}
	for (int i = 0; i < nodeCount; i++) {
		pathForSum[i] = 0;
	}
	for (int i = 0; i < nodeCount; i++) {
		pathForMaxSum[i] = 0;
	}
}

void BST::maximumWidth()
{

}

//finds the path that has the maximum sum of elements between the paths from root to leafs
void BST::maximumSumPath()
{	
	pathIndex = 0;
	elementCount = 0;
	maximumSumPathHelper(root);
	cout << "Maximum sum path is: ";
	for(int i = elementCount - 2; i > 0; i--){
		cout << pathForMaxSum[i] << ", ";
	}
	cout << pathForMaxSum[0] << endl;
	elementCount = 0;
	maxPathSum = 0;
	currSum = 0;
}


//helps to find the max sum path by recursion
void BST::maximumSumPathHelper(Node<int>* nodePtr) {
	//add nodes until you reached to the leaf, make the path array from there, when backtracking, subtract the ints and index
	pathForSum[pathIndex] = nodePtr->getItem(); 
	pathIndex++;
	currSum += nodePtr->getItem(); 

	if ((nodePtr->getLeftChild() == nullptr) && (nodePtr->getRightChild() == nullptr)) {
		if (currSum > maxPathSum) {
			int k = 0;
			for (int i = pathIndex - 1; i >= 0; i--) {
				pathForMaxSum[k] = pathForSum[i];
				k++;
			}
			maxPathSum = currSum;
			elementCount = pathIndex + 1;
		}
	}
	else {
		
		if (nodePtr->getLeftChild() != nullptr) {
			maximumSumPathHelper(nodePtr->getLeftChild());
		}
		if (nodePtr->getRightChild() != nullptr) {
			maximumSumPathHelper(nodePtr->getRightChild());
		}
	}
	//go back to the shared parent of the next node??????????????????????????
	pathIndex--;
	currSum -= nodePtr->getItem();
}