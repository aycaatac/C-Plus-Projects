/**
* Title: Binary Search Trees
* Author : Ayca Candan Atac
* ID: 22203501
* Section : 1
* Homework : 1
* Description : implementation file of the analysis class for the report
*/


#include "analysis.h"
#include "BST.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <iostream>
#include <chrono>
#include <iomanip>
#include <climits>
using namespace std;


//inserts the 10000 random numbers to the empty bst and displays the time and height results in every 1000 insertions
void analysis::timeAnalysis() {
	
		int* arr = new int[10000];
		BST b(arr,0);
		arr = createArray();
		
		auto start_time = chrono::high_resolution_clock::now();
		for (int i = 0; i < 10; i++) {

			for (int k = 0; k < 1000; k++) {
				b.fromConst = true;
				b.insertKey(arr[k + 1000*(i)]);
			}
			auto end_time = chrono::high_resolution_clock::now();
			chrono::duration<double> duration = end_time - start_time;
			cout << "Time passed for 1000 insertions in seconds: " << duration.count() << endl;

			int height = b.getHeight(b.root);
			cout << "The height of the tree after 1000 insertions is: " << height << endl;

			start_time = chrono::high_resolution_clock::now();
		}
		b.fromConst = false;
	
}

//creates 10000 (mostly) random numbers
int* analysis::createArray()
{
	srand(static_cast<unsigned int>(time(0)));
	int* arr = new int[10000];
	int no1;
	int no2;
	for (int i = 0; i < 10000; i++) {
		no1 = rand() % (INT_MAX / 2);
		no2 = rand() % (INT_MAX / 2);
		arr[i] = (no1 + no2)* (no1 / 3);
		
	}
	return arr;
}